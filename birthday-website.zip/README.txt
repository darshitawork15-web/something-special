Birthday website
================
Everything (photos + song) is built into index.html, so it is a single-file website.

To put it online:
1. Netlify Drop (app.netlify.com/drop): drag this whole folder onto the page -> you get a link.
   Or: GitHub Pages / Vercel / Cloudflare Pages -> upload index.html.
2. Or just open index.html in a browser to test it on your computer.

To edit text: open index.html in any text editor and search for the words you want to change
(for example "Babydoll", or the LETTER and quiz text near the bottom of the file).
